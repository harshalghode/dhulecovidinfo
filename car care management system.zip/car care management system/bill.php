<?php 
  require 'config.php';
  session_start();
  error_reporting(0);
$user=$_SESSION['user'];
if($user==true)
{

}
else
{
  header("location:index.php");
}

$mq="SELECT * FROM systemdetails ";
$md=mysqli_query($conn,$mq);
$mr=mysqli_fetch_assoc($md);    

$sid=$_GET['sid'];
//echo $sid;
$q="SELECT * FROM service WHERE sid='$sid'";
$d=mysqli_query($conn,$q);
$r=mysqli_fetch_assoc($d);
?>
<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"> 
    <link rel="stylesheet"  href="css/style.css">
    <link rel="stylesheet"  href="fontawesome-free-5.13.1-web/css/all.css">
  <title>Bill - ADMIN Panel</title>
  <link rel="shortcut icon" type="image/png" href="imgs/new_logo_black.png">
</head>
<body class="bg-secondary">
<header>
      <nav class="navbar navbar-dark bg-dark navbar-expand-md">
        <a class="nav-brand text-white" href="admin-panel.php" >
        <i class="fas fa-car"></i> Car Care Management System <i class="fas fa-car"></i>
            </a>

        <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarToggler">

        <ul class="navbar-nav ml-auto">

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-user"></i>&nbsp;Customer
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="addcustomer.php"><i class="fas fa-user-plus"></i>&nbsp;&nbsp;Add Customer</a>
          <a class="dropdown-item" href="customers.php"><i class="fas fa-users"></i>&nbsp;&nbsp;Manage Customers</a>
          
          </div>
        </li> 
  
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-car"></i>&nbsp;Car
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addcar.php"><i class="fas fa-car"></i>&nbsp;Add Car</a>
            <a class="dropdown-item" href="cars.php"><i class="fas fa-car"></i>&nbsp;Manage Cars</a>
            
          </div>
        </li> 
        <li class="nav-item dropdown active">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-wrench"></i>&nbsp;Service
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addservice.php"> <i class="fa fa-wrench"></i>&nbsp;Add Service</a>
            <a class="dropdown-item active" href="services.php"> <i class="fa fa-wrench"></i>&nbsp;Manage Service</a>
            
          </div>
        </li> 

        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-cog"></i>&nbsp;Accessories
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addaccessories.php"> <i class="fa fa-cog"></i>&nbsp;Add Accessories</a>
            <a class="dropdown-item" href="accessories.php"> <i class="fa fa-cog"></i>&nbsp;Manage Accessories</a>
            
          </div>
        </li> 
        
        <li class="nav-item ">
                <a href="systemdetails.php" class="nav-link"> <i class="fas fa-desktop"></i> System Settings</a>
              </li> 

           

              <li class="nav-item ">
                <a href="admin-logout.php" class="nav-link">Logout</a>
              </li>          
            </ul>


          </div>
      </nav>
      <nav class="navbar navbar-dark bg-secondary navbar-expand-md justify-content-center">
      <button class="btn btn-primary" onClick="window.print()"><h4> <i class="fas fa-print"></i> Print </h4></button>
      </nav>
      </header>

      <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-12 bg-light mt-2 rounded  text-center">
    <h1 class=" p-2">
    <i class="fas fa-car"></i> Car Care Management System <i class="fas fa-car"></i>
    </h1>
    <h6><?= $mr['address'] ?> <br>
     <?= $mr['email'] ?> <br>
      <?= $mr['number'] ?></h6>
    <hr>
    <?php
         $cid=$r['cid'];
         $q1="SELECT * FROM customer WHERE cid='$cid'";
         $d1=mysqli_query($conn,$q1);
         $r1=mysqli_fetch_assoc($d1);
         ?>

    <div class="row">
    <div class="col-6 text-left pl-5">
    <h5> <i class="fas fa-user"></i> <?= $r1['name'] ?></h5>
    <h5> <i class="fas fa-mobile"></i> <?= $r1['mobile'] ?></h5>
    <h5><i class="fas fa-home"></i> <?= $r1['address'] ?></h5>
    </div>
    <div class="col-6 text-right pr-5">
    <h5><i class="fas fa-calendar"></i> <?= $r['date'] ?></h5>
    <h5><i class="fas fa-clock"></i> <?= $r['time'] ?></h5>
    </div>
    </div>
    <hr>
    <div class="row">
    <div class="col-md-12 text-center">
   <h5><i class="fas fa-car"></i> Vehical Details</h5>
    </div>
    </div>

    <?php
         $vid=$r['vid'];
         $q1="SELECT * FROM vehical WHERE vid='$vid'";
         $d1=mysqli_query($conn,$q1);
         $r1=mysqli_fetch_assoc($d1);
         ?>

    <div class="row">
    <div class="col-4 text-left pl-5">
    <h6>Vehical Number: <?= $r1['vnumber'] ?></h6>
   
    </div>
    <div class="col-4 text-center ">
    <h6>Model Number: <?= $r1['mnumber'] ?></h6>
    
    </div>
    <div class="col-4 text-right pr-5">
    <h6>Company: <?= $r1['company'] ?></h6>
    
    </div>
    </div>
    <hr>
    <div class="row">
    <div class="col-md-12 text-center">
   <h5> Bill Details</h5>
    </div>
    </div>

    <div class="row justify-content-center">
    <div class="col-md-10">
    <table class="table table-bordered ">
  <thead>
    <tr>
      <th scope="col">Id</th>
      <th scope="col">Name</th>
      <th scope="col">Price</th>
      
    </tr>
  </thead>

  <tbody>
  <?php
         $sid=$r['sid'];
        $q2="SELECT serviceaccessories.aid, accessories.aid, accessories.name, accessories.price
        FROM serviceaccessories
        INNER JOIN accessories ON accessories.aid = serviceaccessories.aid WHERE serviceaccessories.sid='$sid'";
        $d2=mysqli_query($conn,$q2);
       
        $count=1;
        $total=0;
        while($r2=mysqli_fetch_assoc($d2)){
         ?>
    <tr>
      <th scope="row"><?= $count ?></th>
      <td><?= $r2['name'] ?></td>
      <td>Rs.<?= $r2['price'] ?>/-</td>
      
    </tr>
    <?php
        $total=$total+$r2['price'];
        $count++;
        }
        if($r['labourcharge']!=""){  
        ?>
       <tr>
      <th scope="row"><?= $count ?></th>
      <td>Labour Charges</td>
      <td>Rs.<?= $r['labourcharge'] ?>/-</td>    
    </tr>
    <?php
        $total=$total+$r['labourcharge'];
        $count++;
        }
        if($r['washingcharge']!=""){  
        ?>
         <tr>
      <th scope="row"><?= $count ?></th>
      <td>Washing Charges</td>
      <td>Rs.<?= $r['washingcharge'] ?>/-</td>    
    </tr>
    <?php
        $total=$total+$r['washingcharge'];
        $count++;
        }
        ?>

    <tr>
    <td colspan="2" class="text-right">Grand Total :</td>
    <td>Rs.<?= $total ?>/-</td>
    </tr>
  </tbody>
</table>
    </div>
    </div>
<hr>
<div class="row mt-5 pt-5">
<div class="col-md-6 ">
<h6 class="">Paid</h6>
</div>
<div class="col-md-6 pr-5 text-center">
<h6 class="pr-5"><?= $mr['name'] ?> <br> Cashier</h6>
</div>
</div>
<hr>
<div class="row">
<div class="col-md-12 text-center">
<h5><i class="fas fa-smile"></i> Thank You <i class="fas fa-smile"></i> <br>..... Visit Again .....</h5>
</div>
</div>
    
    
</div>



      <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="bootstrap/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <style>
.dropdown:hover>.dropdown-menu {
  display: block;
}

.dropdown>.dropdown-toggle:active {
  /*Without this, clicking will make it sticky*/
    pointer-events: none;
}
</style>
</body>
</html>