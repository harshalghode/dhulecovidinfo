<?php 
  require 'config.php';
  session_start();
  error_reporting(0);
$user=$_SESSION['user'];
if($user==true)
{

}
else
{
  header("location:index.php");
}
$mq="SELECT * FROM systemdetails ";
$md=mysqli_query($conn,$mq);
$mr=mysqli_fetch_assoc($md);   
  $msg="";
  if(isset($_POST['submit'])){

    $name=$_POST['name'];
    $email=$_POST['email'];
    $number=$_POST['number'];
    $address=$_POST['address'];
    $labourcharge=$_POST['labourcharge'];
    $washingcharge=$_POST['washingcharge'];

    $query="UPDATE  systemdetails SET name='$name', email='$email', number='$number', address='$address', washingcharge='$washingcharge', labourcharge='$labourcharge'  ";
    $data=mysqli_query($conn,$query);

    if($data){
                echo '<script>alert("System Details Update Successfully !!!");window.open("managesystemdetails.php");</script> ';

    }
    else{
        echo '<script>alert("Error !");</script>';
    }
    
    
    
    

   

   
  }
 ?>
<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"> 
    <link rel="stylesheet"  href="css/style.css">
    <link rel="stylesheet"  href="fontawesome-free-5.13.1-web/css/all.css">
  <title>Update System Details</title>
  <link rel="shortcut icon" type="image/png" href="imgs/new_logo_black.png">
</head>
<body class="bg-secondary">

<header>
      <nav class="navbar navbar-dark bg-dark navbar-expand-md">
        <a class="nav-brand text-white" href="admin-panel.php" >
        <i class="fas fa-car"></i> Car Care Management System <i class="fas fa-car"></i>
            </a>

        <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarToggler">

        <ul class="navbar-nav ml-auto">

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-user"></i>&nbsp;Customer
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="addcustomer.php"><i class="fas fa-user-plus"></i>&nbsp;&nbsp;Add Customer</a>
          <a class="dropdown-item" href="customers.php"><i class="fas fa-users"></i>&nbsp;&nbsp;Manage Customers</a>
          
          </div>
        </li> 
  
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-car"></i>&nbsp;Car
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addcar.php"><i class="fas fa-car"></i>&nbsp;Add Car</a>
            <a class="dropdown-item" href="cars.php"><i class="fas fa-car"></i>&nbsp;Manage Cars</a>
            
          </div>
        </li> 
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-wrench"></i>&nbsp;Service
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addservice.php"> <i class="fa fa-wrench"></i>&nbsp;Add Service</a>
            <a class="dropdown-item" href="services.php"> <i class="fa fa-wrench"></i>&nbsp;Manage Service</a>
            
          </div>
        </li> 

        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-cog"></i>&nbsp;Accessories
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addaccessories.php"> <i class="fa fa-cog"></i>&nbsp;Add Accessories</a>
            <a class="dropdown-item" href="accessories.php"> <i class="fa fa-cog"></i>&nbsp;Manage Accessories</a>
            
          </div>
        </li> 
        
        <li class="nav-item active">
                <a href="systemdetails.php" class="nav-link"> <i class="fas fa-desktop"></i> System Settings</a>
              </li> 

           

              <li class="nav-item ">
                <a href="admin-logout.php" class="nav-link">Logout</a>
              </li>          
            </ul>


          </div>
      </nav>
      </header>

<div class="container">
  <div class="row justify-content-center">
    <div class="col-md-6 bg-dark mt-2 rounded">
    <h2 class="text-center text-white p-1">Update System Information</h2>
      <form action="" method="post" class="p-2" enctype="multipart/form-data" id="form-box">
      <div class="form-group">
        <div class="row">
        <div class="col-md-12">
        <span class="text-white"><i class="fas fa-user"></i> Name:-</span>
        <input type="text" name="name" class="form-control" placeholder="Name" value="<?= $mr['name'] ?>">
        </div>
        </div>
      </div>  

      <div class="form-group">
        <div class="row">
        <div class="col-md-12">
        <span class="text-white"><i class="fas fa-envelope"></i> E-mail:-</span>
        <input type="text" name="email" class="form-control" placeholder="Name" value="<?= $mr['email'] ?>">
        </div>
        </div>
      </div>  

      <div class="form-group">
        <div class="row">
        <div class="col-md-12">
        <span class="text-white"><i class="fas fa-phone"></i> Helpline Number:-</span>
        <input type="text" name="number" class="form-control" placeholder="Name" value="<?= $mr['number'] ?>">
        </div>
        </div>
      </div>  

      <div class="form-group">
        <div class="row">
        <div class="col-md-12">
        <span class="text-white"><i class="fas fa-home"></i> Address:-</span>
       <textarea name="address" class="form-control" id="" cols="30" rows="3" placeholder="Address" value="<?= $mr['address'] ?>"><?= $mr['address'] ?></textarea>
        </div>
        </div>
      </div>  

      <div class="form-group">
        <div class="row">
        <div class="col-md-12">
        <span class="text-white"><i class="fa fa-wrench"></i> Labour Charge:-</span>
        <input type="text" name="labourcharge" class="form-control" placeholder="Name" value="<?= $mr['labourcharge'] ?>">
        </div>
        </div>
      </div>  

      <div class="form-group">
        <div class="row">
        <div class="col-md-12">
        <span class="text-white"><i class="fas fa-cog"></i> Washing Charge:-</span>
        <input type="text" name="washingcharge" class="form-control" placeholder="Name" value="<?= $mr['washingcharge'] ?>">
        </div>
        </div>
      </div>  

        <div class="form-group">
          <input type="submit" name="submit" class="btn btn-danger btn-block" value="Update Details">
        </div>  
        <div class="form-group">
          <h4 class="text-center text-white"><?= $msg; ?></h4>
        </div>  
      </form>
    </div>
  </div>
  <div class="row justify-content-center">
    <div class="col-md-6 mt-1  p-2 bg-dark rounded">
      <a href="systemdetails.php" class="btn btn-primary btn-block btn-lg">Go to System Details page
      </a>
    </div>
  </div>
</div>


<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="bootstrap/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<style>
.dropdown:hover>.dropdown-menu {
  display: block;
}

.dropdown>.dropdown-toggle:active {
  /*Without this, clicking will make it sticky*/
    pointer-events: none;
}
</style>
</body>
</html>