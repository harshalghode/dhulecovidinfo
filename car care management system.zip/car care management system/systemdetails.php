<?php 
  require 'config.php';
  session_start();
  error_reporting(0);
$user=$_SESSION['user'];
if($user==true)
{

}
else
{
  header("location:index.php");
}
$mq="SELECT * FROM systemdetails ";
$md=mysqli_query($conn,$mq);
$mr=mysqli_fetch_assoc($md);    


$sid=$_GET['sid'];
//echo $sid;
$q="SELECT * FROM service WHERE sid='$sid'";
$d=mysqli_query($conn,$q);
$r=mysqli_fetch_assoc($d);
?>
<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"> 
    <link rel="stylesheet"  href="css/style.css">
    <link rel="stylesheet"  href="fontawesome-free-5.13.1-web/css/all.css">
  <title>System Details - ADMIN Panel</title>
  <link rel="shortcut icon" type="image/png" href="imgs/new_logo_black.png">
</head>
<body class="bg-secondary">
<header>
      <nav class="navbar navbar-dark bg-dark navbar-expand-md">
        <a class="nav-brand text-white" href="admin-panel.php" >
        <i class="fas fa-car"></i> Car Care Management System <i class="fas fa-car"></i>
            </a>

        <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarToggler">

        <ul class="navbar-nav ml-auto">

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-user"></i>&nbsp;Customer
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="addcustomer.php"><i class="fas fa-user-plus"></i>&nbsp;&nbsp;Add Customer</a>
          <a class="dropdown-item" href="customers.php"><i class="fas fa-users"></i>&nbsp;&nbsp;Manage Customers</a>
          
          </div>
        </li> 
  
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-car"></i>&nbsp;Car
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addcar.php"><i class="fas fa-car"></i>&nbsp;Add Car</a>
            <a class="dropdown-item" href="cars.php"><i class="fas fa-car"></i>&nbsp;Manage Cars</a>
            
          </div>
        </li> 
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-wrench"></i>&nbsp;Service
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addservice.php"> <i class="fa fa-wrench"></i>&nbsp;Add Service</a>
            <a class="dropdown-item" href="services.php"> <i class="fa fa-wrench"></i>&nbsp;Manage Service</a>
            
          </div>
        </li> 

        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-cog"></i>&nbsp;Accessories
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addaccessories.php"> <i class="fa fa-cog"></i>&nbsp;Add Accessories</a>
            <a class="dropdown-item" href="accessories.php"> <i class="fa fa-cog"></i>&nbsp;Manage Accessories</a>
            
          </div>
        </li> 
        
        <li class="nav-item active">
                <a href="systemdetails.php" class="nav-link"> <i class="fas fa-desktop"></i> System Settings</a>
              </li> 

           

              <li class="nav-item ">
                <a href="admin-logout.php" class="nav-link">Logout</a>
              </li>          
            </ul>


          </div>
      </nav>
      </header>

      <div class="container mt-5">
  <div class="row justify-content-center">
    <div class="col-md-6 bg-dark mt-2 rounded text-white ">
    <h2 class="text-center  p-4"><i class="fas fa-desktop"></i> View System Details <i class="fas fa-desktop"></i></h2>

    <table class="ml-5">
    
    <tr>
   
        <th class="pl-5 pb-1">Name :-</th>
        <td class="pl-5 pb-3"><?= $mr['name'] ?>
        </td>
    </tr>
    <tr>
        <th class="pl-5 pb-1">Email-ID :-</th>
        <td class="pl-5 pb-3"><?= $mr['email'] ?></td>
    </tr>
    <tr>
         <th class="pl-5 pb-1">Number :-</th>
        <td class="pl-5 pb-3"><?= $mr['number'] ?></td>
    </tr>
    <tr>
         <th class="pl-5 pb-1">Address :-</th>
        <td class="pl-5 pb-3"><?= $mr['address'] ?></td>
    </tr>
    <tr>
         <th class="pl-5 pb-1">Labour Charge :-</th>
        <td class="pl-5 pb-3">Rs.<?= $mr['labourcharge'] ?>/-</td>
    </tr>
    <tr>
         <th class="pl-5 pb-1">Washing Charge :-</th>
        <td class="pl-5 pb-3">Rs.<?= $mr['washingcharge'] ?>/-</td>
    </tr>
    
    </table>
        <div class="row justify-content-center mt-2 mb-3">
        <div class="col-4">
        <a href="managesystemdetails.php"><button class="btn btn-primary">Manage Details</button></a>
        </div>
        </div>
        
</div>



      <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="bootstrap/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <style>
.dropdown:hover>.dropdown-menu {
  display: block;
}

.dropdown>.dropdown-toggle:active {
  /*Without this, clicking will make it sticky*/
    pointer-events: none;
}
</style>
</body>
</html>