<?php 
  require 'config.php';
  session_start();
  error_reporting(0);
$user=$_SESSION['user'];
if($user==true)
{

}
else
{
  header("location:index.php");
}


$sid=$_GET['sid'];
//echo $sid;
$q="SELECT * FROM service WHERE sid='$sid'";
$d=mysqli_query($conn,$q);
$r=mysqli_fetch_assoc($d);
?>
<!DOCTYPE html>
<html>
<head>
  <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css"> 
    <link rel="stylesheet"  href="css/style.css">
    <link rel="stylesheet"  href="fontawesome-free-5.13.1-web/css/all.css">
  <title>Service Details - ADMIN Panel</title>
  <link rel="shortcut icon" type="image/png" href="imgs/new_logo_black.png">
</head>
<body class="bg-secondary">
<header>
      <nav class="navbar navbar-dark bg-dark navbar-expand-md">
        <a class="nav-brand text-white" href="admin-panel.php" >
        <i class="fas fa-car"></i> Car Care Management System <i class="fas fa-car"></i>
            </a>

        <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarToggler">

        <ul class="navbar-nav ml-auto">

        <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="fas fa-user"></i>&nbsp;Customer
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="addcustomer.php"><i class="fas fa-user-plus"></i>&nbsp;&nbsp;Add Customer</a>
          <a class="dropdown-item" href="customers.php"><i class="fas fa-users"></i>&nbsp;&nbsp;Manage Customers</a>
          
          </div>
        </li> 
  
        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-car"></i>&nbsp;Car
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addcar.php"><i class="fas fa-car"></i>&nbsp;Add Car</a>
            <a class="dropdown-item" href="cars.php"><i class="fas fa-car"></i>&nbsp;Manage Cars</a>
            
          </div>
        </li> 
        <li class="nav-item dropdown active">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-wrench"></i>&nbsp;Service
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addservice.php"> <i class="fa fa-wrench"></i>&nbsp;Add Service</a>
            <a class="dropdown-item active" href="services.php"> <i class="fa fa-wrench"></i>&nbsp;Manage Service</a>
            
          </div>
        </li> 

        <li class="nav-item dropdown ">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          <i class="fa fa-cog"></i>&nbsp;Accessories
          </a>
          <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <a class="dropdown-item " href="addaccessories.php"> <i class="fa fa-cog"></i>&nbsp;Add Accessories</a>
            <a class="dropdown-item" href="accessories.php"> <i class="fa fa-cog"></i>&nbsp;Manage Accessories</a>
            
          </div>
        </li> 
        
        <li class="nav-item ">
                <a href="systemdetails.php" class="nav-link"> <i class="fas fa-desktop"></i> System Settings</a>
              </li> 

           

              <li class="nav-item ">
                <a href="admin-logout.php" class="nav-link">Logout</a>
              </li>          
            </ul>


          </div>
      </nav>
      </header>

      <div class="container">
  <div class="row justify-content-center">
    <div class="col-md-6 bg-dark mt-2 rounded text-white ">
    <h2 class="text-center  p-1">View Service Details</h2>

    <table class="ml-5">
    <tr>
    <th class="pl-5 pb-1">Customer Details :-</th>
    </tr>
    <tr>
    <?php
         $cid=$r['cid'];
         $q1="SELECT * FROM customer WHERE cid='$cid'";
         $d1=mysqli_query($conn,$q1);
         $r1=mysqli_fetch_assoc($d1);
         ?>
        <td class="pl-5 pb-3">Customer Name:</td>
        <td class="pl-5 pb-3"><?= $r1['name'] ?>
        </td>
    </tr>
    <tr>
    <td class="pl-5 pb-3">Mobile Number:</td>
        <td class="pl-5 pb-3"><?= $r1['mobile'] ?></td>
    </tr>
    <tr>
    <td class="pl-5 pb-3">Address:</td>
        <td class="pl-5 pb-3"><?= $r1['address'] ?></td>
    </tr>


    <tr>
    <th class="pl-5 pb-1">Vehical Details :-</th>
    </tr>
    <tr>
    <?php
         $vid=$r['vid'];
         $q1="SELECT * FROM vehical WHERE vid='$vid'";
         $d1=mysqli_query($conn,$q1);
         $r1=mysqli_fetch_assoc($d1);
         ?>
        <td class="pl-5 pb-3">Vehical Number:</td>
        <td class="pl-5 pb-3"><?= $r1['vnumber'] ?>
        </td>
    </tr>
    <tr>
    <td class="pl-5 pb-3">Model Number:</td>
        <td class="pl-5 pb-3"><?= $r1['mnumber'] ?></td>
    </tr>
    <tr>
    <td class="pl-5 pb-3">Company:</td>
        <td class="pl-5 pb-3"><?= $r1['company'] ?></td>
    </tr>

    <tr>
    <th class="pl-5 pb-1" colspan="2">Service Details :-</th>
    </tr>
    
    <?php
    if($r['labourcharge']!=""){?>
      <tr>
      <td class="pl-5 pb-3">Labour Charge:</td>
        <td class="pl-5 pb-3">Rs.<?= $r['labourcharge'] ?>/-</td>
    </tr>
    <?php 
    }
    if($r['washingcharge']!=""){?>
      <tr>
      <td class="pl-5 pb-3">Washing Charge:</td>
        <td class="pl-5 pb-3">Rs.<?= $r['washingcharge'] ?>/-</td>
    </tr>
    <?php } ?>
    
   

    <tr>
    <th class="pl-5 pb-1" colspan="2">Accessorie Details :-</th>
    </tr>
    <?php
         $sid=$r['sid'];
        $q2="SELECT serviceaccessories.aid, accessories.aid, accessories.name, accessories.price
        FROM serviceaccessories
        INNER JOIN accessories ON accessories.aid = serviceaccessories.aid WHERE serviceaccessories.sid='$sid'";
        $d2=mysqli_query($conn,$q2);
        while($r2=mysqli_fetch_assoc($d2)){
         ?>
         <tr>         
        <td class="pl-5 pb-3"><?= $r2['name'] ?></td>
        <td class="pl-5 pb-3">Rs.<?= $r2['price'] ?>/-</td>
         </tr>
         <?php
        }
        ?>
          <tr>
    <th class="pl-5 pb-1" colspan="2">Date/Time Details :-</th>
    </tr>
    <tr>
    <td class="pl-5 pb-3">Date:</td>
        <td class="pl-5 pb-3"><?= $r['date'] ?></td>
    </tr>
    <tr>
    <td class="pl-5 pb-3">Time:</td>
        <td class="pl-5 pb-3"><?= $r['time'] ?></td>
    </tr>

    
   
    
    </table>
    
</div>



      <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="bootstrap/js/jquery-3.5.1.slim.min.js"></script>
    <script src="bootstrap/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <style>
.dropdown:hover>.dropdown-menu {
  display: block;
}

.dropdown>.dropdown-toggle:active {
  /*Without this, clicking will make it sticky*/
    pointer-events: none;
}
</style>
</body>
</html>