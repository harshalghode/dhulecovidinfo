<?php 
	session_start();
	$uid=$_SESSION['user'];
	require 'config.php';

	

	if(isset($_GET['aid'])){
		$aid = $_GET['aid'];

		$stmt = $conn->prepare("DELETE FROM accessories WHERE aid=?");
		$stmt->bind_param("i",$aid);
		$stmt->execute();

		$_SESSION['showAlert'] = 'block';
		$_SESSION['message'] = 'Accessories Deleted ! ';
		header('location:accessories.php');
	}


 ?>	  