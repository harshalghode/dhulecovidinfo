<?php 
	session_start();
	$uid=$_SESSION['user'];
	require 'config.php';

	

	if(isset($_GET['vid'])){
		$vid = $_GET['vid'];

		$stmt = $conn->prepare("DELETE FROM vehical WHERE vid=?");
		$stmt->bind_param("i",$vid);
		$stmt->execute();

		$_SESSION['showAlert'] = 'block';
		$_SESSION['message'] = 'Car Deleted ! ';
		header('location:cars.php');
	}


 ?>	  