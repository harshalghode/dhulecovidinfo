<?php 
 $conn = new mysqli("localhost","root","","carcare");
 if($conn->connect_error){
 	die("Connection Failed !".$conn->connect_error);
 	
 }
  ?>